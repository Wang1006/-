package net.fuzui.StudentInfo.mysql_rws;
/**
 * @author fuzui
 * @date 2019年3月17日 下午5:29:15
 * 
 */
public enum DynamicDataSourceGlobal {
	READ,WRITE;
}
